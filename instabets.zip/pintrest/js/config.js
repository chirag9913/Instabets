









// Check if Firebase is already initialized
if (!window.firebase.apps.length) {
    const firebaseConfig = {
        apiKey: "AIzaSyA_nqAhQQVSx34L9f9e2d4qd1EwZ0RuEhE",
        authDomain: "instabets-41bdb.firebaseapp.com",
        projectId: "instabets-41bdb",
        storageBucket: "instabets-41bdb.firebasestorage.app",
        messagingSenderId: "492892340821",
        appId: "1:492892340821:web:a5be7146e338e2441fcadc"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
}

// Initialize Firestore globally if not already initialized
if (!window.db) {
    window.db = firebase.firestore();
}

// Supabase configuration
if (!window.supabaseClient) {
    const supabaseUrl = 'https://ibytvpbneyanfiuryujm.supabase.co';
    const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlieXR2cGJuZXlhbmZpdXJ5dWptIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ5NjI3MjYsImV4cCI6MjA2MDUzODcyNn0.nw1qD7I6XGSE6W0WpL8O9Scoh1y466riGQ8RPO2NG90';

    const { createClient } = supabase;
    window.supabaseClient = createClient(supabaseUrl, supabaseKey);
}