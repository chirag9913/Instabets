const auth = firebase.auth();

async function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        await auth.signInWithEmailAndPassword(email, password);
        window.location.href = 'home.html';
    } catch (error) {
        document.getElementById('authMessage').textContent = error.message;
    }
}

async function register() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        await createUserProfile(userCredential.user.uid);
        window.location.href = 'home.html';
    } catch (error) {
        document.getElementById('authMessage').textContent = error.message;
    }
}

async function createUserProfile(uid) {
    const db = firebase.firestore();
    await db.collection('users').doc(uid).set({
        email: auth.currentUser.email,
        username: '',
        bio: '',
        profileImage: ''
    });
}

function logout() {
    auth.signOut().then(() => {
        window.location.href = 'index.html';
    });
}

// Auth state observer
auth.onAuthStateChanged((user) => {
    if (!user && !window.location.href.includes('index.html')) {
        window.location.href = 'index.html';
    }
});