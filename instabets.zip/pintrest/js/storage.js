const db = firebase.firestore(); // Add this line at the top

// Add this function if it's not already in storage.js
// Remove the db initialization line
async function uploadImage(file, folder) {
    try {
        const storageRef = firebase.storage().ref();
        const fileRef = storageRef.child(`${folder}/${Date.now()}_${file.name}`);
        const snapshot = await fileRef.put(file);
        const downloadURL = await snapshot.ref.getDownloadURL();
        return downloadURL;
    } catch (error) {
        console.error('Error uploading file:', error);
        throw error;
    }
}

async function updateProfileImage() {
    const file = document.getElementById('profileImageInput').files[0];
    if (!file) return;

    try {
        const imageUrl = await uploadImage(file, 'profiles');
        if (!imageUrl) return;
        
        const userRef = db.collection('users').doc(auth.currentUser.uid);
        
        // Check if document exists
        const doc = await userRef.get();
        if (!doc.exists) {
            // Create the document if it doesn't exist
            await userRef.set({
                profileImage: imageUrl,
                username: 'User',
                bio: ''
            });
        } else {
            // Update existing document
            await userRef.update({
                profileImage: imageUrl
            });
        }

        document.getElementById('profileImage').src = imageUrl;
    } catch (error) {
        console.error('Error updating profile image:', error);
    }
}

async function updateProfile() {
    const username = document.getElementById('username').value;
    const bio = document.getElementById('bio').value;

    try {
        const db = firebase.firestore();
        const userRef = db.collection('users').doc(auth.currentUser.uid);
        
        // Check if document exists
        const doc = await userRef.get();
        if (!doc.exists) {
            // Create the document if it doesn't exist
            await userRef.set({
                username: username,
                bio: bio
            });
        } else {
            // Update existing document
            await userRef.update({
                username: username,
                bio: bio
            });
        }
        alert('Profile updated successfully!');
    } catch (error) {
        console.error('Error updating profile:', error);
        alert('Failed to update profile');
    }
}

// Remove the profile load section at the bottom since it's now handled in profile.html