const db = firebase.firestore();
// Remove duplicate auth declaration since it's already in auth.js

async function createPost() {
    if (!auth.currentUser) {
        window.location.href = 'index.html';
        return;
    }

    const text = document.getElementById('postText').value;
    const imageFile = document.getElementById('postImage').files[0];
    
    try {
        let imageUrl = null;
        
        if (imageFile) {
            try {
                imageUrl = await uploadImage(imageFile, 'posts');
            } catch (uploadError) {
                console.error('Upload error:', uploadError);
                // Continue without image if upload fails
            }
        }

        const postData = {
            userId: auth.currentUser.uid,
            text: text,
            timestamp: firebase.firestore.FieldValue.serverTimestamp(),
            likes: 0
        };

        if (imageUrl) {
            postData.imageUrl = imageUrl;
        }

        await db.collection('posts').add(postData);
        document.getElementById('postText').value = '';
        document.getElementById('postImage').value = '';
        loadPosts();
    } catch (error) {
        console.error('Error creating post:', error);
    }
}

async function loadPosts() {
    const postsContainer = document.getElementById('posts');
    postsContainer.innerHTML = '';

    try {
        const snapshot = await db.collection('posts')
            .orderBy('timestamp', 'desc')
            .get();

        for (const doc of snapshot.docs) {
            const post = doc.data();
            let userData = { username: 'Anonymous', profileImage: null };
            
            // Only fetch user data if userId exists and is not empty
            if (post.userId && post.userId.trim() !== '') {
                try {
                    const userDoc = await db.collection('users').doc(post.userId).get();
                    if (userDoc.exists) {
                        userData = userDoc.data();
                    }
                } catch (userError) {
                    console.error('Error fetching user data:', userError);
                }
            }
            
            post.userProfileImage = userData.profileImage;
            post.username = userData.username || 'Anonymous';
            
            const postElement = createPostElement(doc.id, post);
            postsContainer.appendChild(postElement);
        }
    } catch (error) {
        console.error('Error loading posts:', error);
    }
}

function createPostElement(postId, post) {
    const defaultAvatar = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyBAMAAADsEZWCAAAAG1BMVEXMzMyWlpacnJyqqqrFxcWxsbGjo6O3t7e+vr6He3KoAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAOElEQVQ4jWNgQAX/GbAD/AqwK8CqALsB2BVgVYBdAXYF2BXgUIBdAXYF2BVgV4BdAXYF2BVgUgAAUxAW1dLaPeAAAAAASUVORK5CYII=';
    
    const div = document.createElement('div');
    div.className = 'post';
    div.innerHTML = `
        <div class="post-header">
            <img src="${post.userProfileImage || defaultAvatar}" 
                alt="Profile" 
                class="post-profile-image">
            <span>${post.username}</span>
        </div>
        <p>${post.text}</p>
        ${post.imageUrl ? `<img src="${post.imageUrl}" alt="Post image" class="post-image">` : ''}
        <div class="post-actions">
            <button onclick="likePost('${postId}')">${post.likes} Likes</button>
        </div>
    `;
    return div;
}

async function likePost(postId) {
    const postRef = db.collection('posts').doc(postId);
    await postRef.update({
        likes: firebase.firestore.FieldValue.increment(1)
    });
    loadPosts();
}

// Load posts when the page loads
if (window.location.href.includes('home.html')) {
    loadPosts();
}