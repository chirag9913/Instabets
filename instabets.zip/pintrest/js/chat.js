// Remove this line since db is already initialized in config.js
// const db = firebase.firestore();

// Remove db declaration and use window.db instead
let currentChatUser = null;

async function searchUsers() {
    const searchInput = document.getElementById('userSearch').value.toLowerCase();
    const searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = '';

    if (searchInput.length < 2) return;

    try {
        const usersSnapshot = await db.collection('users').get();
        usersSnapshot.forEach(doc => {
            const userData = doc.data();
            if (userData.username && userData.username.toLowerCase().includes(searchInput)) {
                const userDiv = document.createElement('div');
                userDiv.className = 'user-result';
                userDiv.innerHTML = `
                    <img src="${userData.profileImage || 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyBAMAAADsEZWCAAAAG1BMVEXMzMyWlpacnJyqqqrFxcWxsbGjo6O3t7e+vr6He3KoAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAOElEQVQ4jWNgQAX/GbAD/AqwK8CqALsB2BVgVYBdAXYF2BXgUIBdAXYF2BVgV4BdAXYF2BVgUgAAUxAW1dLaPeAAAAAASUVORK5CYII='}" alt="Profile">
                    <span>${userData.username}</span>
                `;
                userDiv.onclick = () => startChat(doc.id, userData);
                searchResults.appendChild(userDiv);
            }
        });
    } catch (error) {
        console.error('Error searching users:', error);
    }
}

function startChat(userId, userData) {
    currentChatUser = { id: userId, ...userData };
    const chatHeader = document.getElementById('chatHeader');
    chatHeader.innerHTML = `
        <img src="${userData.profileImage || 'default-avatar.png'}" alt="Profile">
        <span>${userData.username}</span>
    `;
    loadMessages(userId);
    document.getElementById('searchResults').innerHTML = '';
    document.getElementById('userSearch').value = '';
}

async function loadMessages(otherUserId) {
    const messages = document.getElementById('messages');
    messages.innerHTML = '';
    
    const chatId = getChatId(auth.currentUser.uid, otherUserId);
    
    try {
        // Real-time messages listener with error handling
        db.collection('messages')
            .where('chatId', '==', chatId)
            .onSnapshot(snapshot => {
                // Get all messages and sort manually
                const sortedMessages = [];
                snapshot.forEach(doc => {
                    sortedMessages.push(doc.data());
                });
                
                // Sort by timestamp
                sortedMessages.sort((a, b) => {
                    const timeA = a.timestamp?.seconds || 0;
                    const timeB = b.timestamp?.seconds || 0;
                    return timeA - timeB;
                });

                // Clear existing messages
                messages.innerHTML = '';
                
                // Display sorted messages
                sortedMessages.forEach(message => {
                    displayMessage(message);
                });
                
                messages.scrollTop = messages.scrollHeight;
            }, error => {
                console.error('Error in messages listener:', error);
            });
    } catch (error) {
        console.error('Error setting up messages listener:', error);
    }
}

// Add after your existing functions, before the auth state listener

async function handleMediaUpload() {
    const mediaInput = document.getElementById('mediaInput');
    const file = mediaInput.files[0];
    if (!file) return;

    try {
        const imageUrl = await uploadImage(file, 'chats');
        if (imageUrl) {
            await sendMediaMessage(imageUrl, file.type.startsWith('image') ? 'image' : 'video');
        }
        mediaInput.value = '';
    } catch (error) {
        console.error('Error uploading media:', error);
    }
}

async function sendMediaMessage(mediaUrl, mediaType) {
    if (!currentChatUser) return;

    const chatId = getChatId(auth.currentUser.uid, currentChatUser.id);
    
    try {
        await db.collection('messages').add({
            chatId: chatId,
            senderId: auth.currentUser.uid,
            receiverId: currentChatUser.id,
            mediaUrl: mediaUrl,
            mediaType: mediaType,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (error) {
        console.error('Error sending media message:', error);
    }
}

// Update the existing displayMessage function
function displayMessage(message) {
    const messages = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${message.senderId === auth.currentUser.uid ? 'sent' : 'received'}`;

    if (message.mediaUrl) {
        if (message.mediaType === 'image') {
            messageDiv.innerHTML = `<img src="${message.mediaUrl}" alt="Shared image" class="message-media">`;
        } else if (message.mediaType === 'video') {
            messageDiv.innerHTML = `<video src="${message.mediaUrl}" controls class="message-media"></video>`;
        }
    } else if (message.text) {
        messageDiv.textContent = message.text;
    }

    messages.appendChild(messageDiv);
}

async function sendMessage() {
    if (!currentChatUser) return;

    const messageInput = document.getElementById('messageInput');
    const text = messageInput.value.trim();
    
    if (!text) return;

    const chatId = getChatId(auth.currentUser.uid, currentChatUser.id);
    
    try {
        await db.collection('messages').add({
            chatId: chatId,
            senderId: auth.currentUser.uid,
            receiverId: currentChatUser.id,
            text: text,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        messageInput.value = '';
    } catch (error) {
        console.error('Error sending message:', error);
    }
}

function getChatId(uid1, uid2) {
    return [uid1, uid2].sort().join('_');
}


// Add these functions after your existing code

async function loadRecentChats() {
    const recentChatsDiv = document.createElement('div');
    recentChatsDiv.className = 'recent-chats';
    recentChatsDiv.innerHTML = '<h3>Recent Chats</h3>';
    
    try {
        const currentUserId = auth.currentUser.uid;
        const messagesSnapshot = await db.collection('messages')
            .where('senderId', '==', currentUserId)
            .get();

        const receiverIds = new Set();
        messagesSnapshot.forEach(doc => {
            const message = doc.data();
            receiverIds.add(message.receiverId);
        });

        // Get received messages
        const receivedSnapshot = await db.collection('messages')
            .where('receiverId', '==', currentUserId)
            .get();

        receivedSnapshot.forEach(doc => {
            const message = doc.data();
            receiverIds.add(message.senderId);
        });

        for (const userId of receiverIds) {
            const userDoc = await db.collection('users').doc(userId).get();
            const userData = userDoc.data();
            
            const chatItem = document.createElement('div');
            chatItem.className = 'recent-chat-item';
            chatItem.innerHTML = `
                <img src="${userData.profileImage || 'default-avatar.png'}" alt="Profile">
                <div class="chat-info">
                    <div class="name">${userData.username}</div>
                    <div class="last-message">Click to chat</div>
                </div>
            `;
            chatItem.onclick = () => startChat(userId, userData);
            recentChatsDiv.appendChild(chatItem);
        }

        // Insert recent chats after the search results
        const searchResults = document.getElementById('searchResults');
        searchResults.parentNode.insertBefore(recentChatsDiv, searchResults.nextSibling);

    } catch (error) {
        console.error('Error loading recent chats:', error);
    }
}

// Modify your existing auth state listener to include recent chats
firebase.auth().onAuthStateChanged(user => {
    if (user) {
        loadRecentChats();
    }
});